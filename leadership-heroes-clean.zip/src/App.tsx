import LeadershipHeroesGame from './LeadershipHeroesGame'

export default function App() {
  return <LeadershipHeroesGame />
}
